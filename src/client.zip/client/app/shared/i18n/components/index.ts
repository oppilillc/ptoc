export * from './lang-switcher.component';
