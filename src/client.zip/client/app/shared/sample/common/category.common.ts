export const CATEGORY: string = 'Sample';
