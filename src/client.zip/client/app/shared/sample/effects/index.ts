export * from './name-list.effect';
