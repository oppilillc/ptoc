import { NameListService } from './name-list.service';

export const SAMPLE_PROVIDERS: any[] = [
  NameListService
];

export * from './name-list.service';
