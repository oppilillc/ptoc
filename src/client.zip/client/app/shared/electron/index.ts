// services
export * from './services/event.service';

// utils
export * from './utils/desktop-config';
