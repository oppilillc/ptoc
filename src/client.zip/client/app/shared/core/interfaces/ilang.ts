// standard language interface
export interface ILang {
  code: string;
  title: string;
}
